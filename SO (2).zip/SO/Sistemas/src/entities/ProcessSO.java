package entities;

import java.util.LinkedList;
import java.util.List;

public class ProcessSO {
	private String id;
	private int sizeInMemory;
	private static int countIndex=0;
	private List<String>subProcesses;
	private PriorityType priority;
    private int timeToExecute;

	

	public ProcessSO(int sizeInMemory, int timeToExecute, PriorityType priority) {
		countIndex++;
		this.id="p"+countIndex;
		this.sizeInMemory=sizeInMemory;
		this.timeToExecute = timeToExecute;
		this.priority = priority;

	}
	
	public ProcessSO(String id) {
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getSizeInMemory() {
		return sizeInMemory;
	}
	public void setSizeInMemory(int sizeInMemory) {
		this.sizeInMemory = sizeInMemory;
	}
	
	public List<String> getSubProcesses(){
		if(this.subProcesses ==null || this.subProcesses.isEmpty()) {
			this.subProcesses= new LinkedList<String>();
			for(int i=0;i<this.getSizeInMemory();i++) {
				this.subProcesses.add(id+i);
			}
		}
		
		return this.subProcesses;
	}

	public PriorityType getPriority() {
		return priority;
	}

	public void setPriority(PriorityType priority) {
		this.priority = priority;
	}

	public int getTimeToExecute() {
		return timeToExecute;
	}

	public void setTimeToExecute(int timeToExecute) {
		this.timeToExecute = timeToExecute;
	}
	public boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

	
	}