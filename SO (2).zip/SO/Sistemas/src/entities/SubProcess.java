package entities;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class SubProcess{
    private String id;
    private String processId;
    private int instructions;
    private int timeToExecute;
    private PriorityType priority;

    public SubProcess(String processId,int id, int instructions) {
        this.processId = processId;
       
        this.id =processId+ id;
      
        this.instructions = instructions;
        Random rand = new Random();
        List<Integer> givenList = Arrays.asList(100, 200, 300, 400, 500, 600, 700, 800, 900, 1000);
        this.timeToExecute = givenList.get(rand.nextInt(givenList.size()));

        List<PriorityType> otherList = Arrays.asList(PriorityType.BAIXA, PriorityType.MEDIA, PriorityType.ALTA, PriorityType.CRITICA);
        this.priority = otherList.get(rand.nextInt(otherList.size()));

       
        
    }
    

   

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getInstructions() {
        return instructions;
    }

    public void setInstructions(int instructions) {
        this.instructions = instructions;
    }

    public int getTimeToExecute() {
        return timeToExecute;
    }

    public void setTimeToExecute(int timeToExecute) {
        this.timeToExecute = timeToExecute;
    }

    public String getProcessId() {
        return processId;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
    }

    public PriorityType getPriority() {
        return priority;
    }

    public void setPriority(PriorityType priority) {
        this.priority = priority;
    }




	@Override
	public String toString() {
		return " ["+ id + "]";
	}
  
}
