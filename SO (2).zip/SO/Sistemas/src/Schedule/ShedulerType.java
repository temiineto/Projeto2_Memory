package Schedule;

public enum ShedulerType {
	FCFS(0),SJF(1),PRIORITY(2),LOTERRY(3);
	private int shedulerType;
	
	ShedulerType(int ShedulerType){
		 this.shedulerType=ShedulerType;
	 }

	public int getShedulerType() {
		return shedulerType;
	}

	
}
