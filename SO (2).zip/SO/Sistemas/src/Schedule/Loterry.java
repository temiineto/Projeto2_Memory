package Schedule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import cpu.Core;
import entities.ProcessSO;
import entities.SubProcess;
import entities.SystemCallType;
import entities.SystemOperation;
import exception.NoSpaceException;

public class Loterry extends SchedulerQueue {

    public Loterry() {
        super(new Comparator<ProcessSO>() {
            @Override
            public int compare(ProcessSO p1, ProcessSO p2) {
               return 0;
            }
        });
        System.out.println("Scheduler Loterry");
    }

    @Override
    public void registerProcess() throws NoSpaceException {
        System.out.println("\n\n ************************ EXECUÇÃO DA FILA DE LOTERRY *****************************\n\n");

        Random random = new Random();

        while (!queue.isEmpty()) {
            System.out.println("Tamanho da fila em loterry: "+ queue.size() );

            int randomIndex = random.nextInt(queue.size()); 
            System.out.println("Foi sorteado na fila o número(0 a  " + (queue.size()-1)+"): "+randomIndex);
            ProcessSO p = null;

            int currentIndex = 0;
            for (ProcessSO process : queue) {
                if (currentIndex == randomIndex) {
                    p = process;
                    break;
                }
                currentIndex++;
            }

            if (p != null) {
                queue.remove(p); // Remove o processo sorteado da fila

                System.out.println("Registrando nos cores : " + p.getId());

                List<SubProcess> sps = getSubProcesses().get(p.getId());
                Core[] cores = getCpu().getCores();
                SubProcess sp = null;
                while (!sps.isEmpty()) {
                    for (Core core : cores) {
                        if (core.getSubProcess() == null && !sps.isEmpty()) {
                            sp = sps.remove(0);
                            getCpu().registerProcess(core.getId(), sp);
                        }
                    }
                }

                System.out.println("\n\nFINALIZADO REGISTROS NOS CORES DO PROCESSO: " + sp.getProcessId() + "\n\n");
                super.stopClock();

            }
        }
    }
    
}