package Schedule;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import cpu.Core;
import entities.ProcessSO;
import entities.SubProcess;
import entities.SystemCallType;
import entities.SystemOperation;

public class FCFS extends SchedulerQueue {
	
	
	public FCFS() {
		super(new Comparator<ProcessSO>() {

			
			@Override
			public int compare(ProcessSO o1, ProcessSO o2) {
				return 1;
			}
			
		});
		System.out.println(" Scheduler  FCFS");

	}
	
	
}
