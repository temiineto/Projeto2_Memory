package Schedule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.PriorityQueue;

import cpu.Core;
import cpu.CpuManager;
import entities.ProcessSO;
import entities.SubProcess;
import entities.SystemCallType;
import entities.SystemOperation;
import exception.NoSpaceException;

public abstract class SchedulerQueue extends Scheduler {

    protected PriorityQueue<ProcessSO> queue;
    private List<ProcessSO> processList; // Lista para armazenar os processos na ordem de chegada

    private Hashtable<String, List<SubProcess>> subProcesses;
    private Comparator<ProcessSO> comparator;

    public SchedulerQueue(Comparator<ProcessSO> comparator) {
        this.queue = new PriorityQueue<>(comparator);
        this.processList = new ArrayList<>();
        this.subProcesses = new Hashtable<>();
        this.comparator = comparator;
        this.cpu = new CpuManager();
    }
    
    public void add(ProcessSO p) throws NoSpaceException {
        System.out.println("\n\nAdd na queue: " + p.getId());

        processList.add(p);
        // Ordenar a lista de processos de acordo com o comparador
        processList.sort(comparator);

        // Limpar a fila de prioridade
        queue.clear();

        // Adicionar os processos ordenados à fila de prioridade
        queue.addAll(processList);
        /*
         * isso ta sendo feito  pois estava dando problema  no priority, com a mesma logica n esta dando o resultado esperado
         * ele estava empurrando o processo comparado para o final da list
         */

        List<SubProcess> sps = SystemOperation.systemCall(SystemCallType.READ_PROCESS, p);
        System.out.println(sps.toString());

        this.subProcesses.put(p.getId(), sps);
        System.out.println("Queue size: " + this.queue.size());
        System.out.print("Queue order: ");
        for (ProcessSO pr : queue) {
            System.out.print(pr.getId() + " ");
        }
        System.out.println("\n\n");
    }
    @Override
    public void execute(ProcessSO p) throws NoSpaceException {
    	if(p!=null) {
    		add(p);
    	}else {
        this.registerProcess();
    	}
    }

    public void registerProcess() throws NoSpaceException {
		System.out.println("\n\n ************************ EXECUÇÃO DA FILA NA SUPER *****************************\n\n");

    	for(ProcessSO p : this.queue) {
    		System.out.println("Registrando nos cores : " +p.getId());

            List<SubProcess> sps = this.subProcesses.get(p.getId());
            System.out.println("IDS dos subprocesso de " + p.getId()+": " + sps.toString());
           
            Core[] cores = this.getCpu().getCores();
            SubProcess sp =null;
            while(!sps.isEmpty()) {
            	for (Core core : cores) {
                    if (core.getSubProcess() == null && sps.size()>0) { 
                           sp = sps.remove(0);
                           this.getCpu().registerProcess(core.getId(), sp);
                           break;
                        }
                    }
            }

            System.out.println("\n\nFINALIZADO REGISTROS NOS CORES DO PROCESSO: " + sp.getProcessId() +"\n\n");
            super.stopClock();
    	}
    	
        
            
    }
    
	@Override
	public void finish(ProcessSO p) {
		// TODO Auto-generated method stub
		
	}
	public void printQueue() {
	    PriorityQueue<ProcessSO> queue = getQueue();
	    for (ProcessSO p : queue) {
	        System.out.println(p.getId());
	    }
	}
    public PriorityQueue<ProcessSO> getQueue() {
        return queue;
    }

    public Hashtable<String, List<SubProcess>> getSubProcesses() {
        return subProcesses;
    }

    public void setSubProcesses(Hashtable<String, List<SubProcess>> subProcesses) {
        this.subProcesses = subProcesses;
    }

    public Comparator<ProcessSO> getComparator() {
        return comparator;
    }


}
