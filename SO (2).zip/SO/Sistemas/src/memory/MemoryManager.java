package memory;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import entities.ProcessSO;
import entities.SubProcess;

public class MemoryManager {
	private int pageSize;
	private Strategy strategy=Strategy.PAGING;
	private SubProcess[][] physicalmemory;
	private Hashtable<String,FrameMemory> logicalMemory;
	public static int NUMBER_OF_PROCESS_INSTRUCTIONS =7;
	

	public MemoryManager(int pageSize,int memorySize) {
		this.strategy = Strategy.PAGING;
		this.pageSize=pageSize;
		int pages= memorySize/pageSize;
		this.physicalmemory = new SubProcess[pages][pageSize];
		this.logicalMemory= new Hashtable<>();
        System.out.println("Pages: "+ pages + "    PageSize: "+ pageSize);
        System.out.println();


	}
	
	 private List<FrameMemory> getFrames(ProcessSO p) {
	        int totalPages = p.getSizeInMemory() / this.pageSize;
	        List<FrameMemory> frames = new LinkedList<>();

	        for (int frame = 0; frame < this.physicalmemory.length; frame++) {
	            if (this.physicalmemory[frame][0] == null) {
	                frames.add(new FrameMemory(frame, 0));
	                if (frames.size() >= totalPages) {
	                    return frames;
	                }
	            }
	        }
	        return null; 
	    }
	  private void printMemoryStatus() {
       System.out.println("***** memory *******");

	        for (int i = 0; i < this.physicalmemory.length; i++) {
	        	if(i<9) {
	                System.out.print("Page 0"+ (i+1) + ": ");

	        	}else {
	                System.out.print("Page "+ (i+1) + ": ");

	        	}

	            for (int j = 0; j < this.pageSize; j++) {
	                if (this.physicalmemory[i][j] != null) {
	                    System.out.print(this.physicalmemory[i][j].getId() + " | ");
	                } else {
	                    System.out.print("Empty | ");
	                }
	            }
	            System.out.println();
	        }
	    }
	  private List<FrameMemory> getRemainingFrames(ProcessSO p) {
		    int totalPages = (int) Math.ceil((double) p.getSubProcesses().size() / pageSize);
		    List<FrameMemory> remainingFrames = new ArrayList<>();

		    for (int i = 0; i < physicalmemory.length; i++) {
		        if (remainingFrames.size() >= totalPages) {
		            break; // Já temos frames suficientes para alocar todos os subprocessos restantes
		        }
		        if (physicalmemory[i][0] == null) {
		            remainingFrames.add(new FrameMemory(i, 0));
		        }
		    }
		    return remainingFrames.size() >= totalPages ? remainingFrames : null;
		}

	  public boolean write(ProcessSO p) {
		  System.out.println("WRITE: "+ p.getSubProcesses());
		    List<FrameMemory> frames = getRemainingFrames(p);
		    if (frames == null) {
		        System.out.println("\n\nNão foi possivel alocar o processo por falta se espaço na memório. Processo negado: "+p.getId()+"\n\n");
		        return false; 
		    }
		    
		    int remainingInstructions = p.getSubProcesses().size();
		    for (FrameMemory frame : frames) {
		        for (int offset = 0; offset < this.pageSize && remainingInstructions > 0; offset++) {
		            // Cria um subprocesso com o ID adequado
		            SubProcess sp = new SubProcess(p.getId() ,(p.getSubProcesses().size() - remainingInstructions),
		                                            NUMBER_OF_PROCESS_INSTRUCTIONS);

		            // Coloca o subprocesso na memória física e atualiza a memória lógica
		            this.physicalmemory[frame.getPageNumber()][offset] = sp;

		            FrameMemory neFrame = new FrameMemory(frame.getPageNumber(),offset);
		            /*
		             * estava dando problema no registro com o frame.setDisplacemnt(offset) e tava sempre salvado como 3
		             * oq fazia que a execução  ficasse 
		             * Core 0  executando
						Executing process: p168
						Core 1  executando
						Executing process: p168
						Core 2  executando
						Executing process: p168
						Core 3  executando
						Executing process: p168
						e so mudava o numero do sub processop quando passava a pagina, dessa forma foi corrigido esse problema
		             */

		            this.logicalMemory.put(sp.getId(), neFrame);

		            remainingInstructions--;
		        }
		    }
		    
		    printMemoryStatus();
		    return true;
		}



	  public boolean delete(ProcessSO p) {
	        boolean found = false;
	        for (int i = 0; i < physicalmemory.length; i++) {
	            for (int j = 0; j < pageSize; j++) {
	                SubProcess sub = physicalmemory[i][j];
	                if (sub != null && sub.getProcessId().equals(p.getId())) {
	                    physicalmemory[i][j] = null; // Limpa o frame
	                    found = true;
	                }
	            }
	        }
	        if (found) {
	            printMemoryStatus();
	            System.out.println("Process " + p.getId() + " has been deleted from memory.");
	        } else {
	            System.out.println("Process " + p.getId() + " not found in memory.");
	        }
	        return found;
	    }
	  public List<SubProcess> read(ProcessSO p) {

		    List<String> ids = p.getSubProcesses();
		    List<SubProcess> sps = new LinkedList<>();

		    for (String id : ids) {
		    	FrameMemory frame= this.logicalMemory.get(id);
		        if (frame!=null) {
		            sps.add(physicalmemory[frame.getPageNumber()][frame.getDisplacement()]);
		        } else {
		            System.out.println("Erro: Referência de frame inválida para o subprocesso "  + id + " e seus subsequentes");
		            break;
		        }
		    }
		    return sps;
		}
	
}
