package cpu;

import entities.SubProcess;

public class Core implements Runnable {
	private int id;
	private SubProcess subProcess;
	private int numOInstructionsPerClock;
    private boolean running;

	private int count;
	private boolean active = true;
	
	public Core(int coreId, int numOInstructionsPerClock) {
		this.id=coreId;
		this.numOInstructionsPerClock = numOInstructionsPerClock;
        this.running = true;

	}
	 @Override
	    public void run() {
	        this.running = true;

	        while (running) {
	            if (subProcess != null) {
	                System.out.println("--- Executing process: " + subProcess.getId());
	                processInstructions();
	            }else {
					this.finishExecution();

				}
	        }
	    }
	
    private void processInstructions() {
    	if(subProcess != null) {
	        count += numOInstructionsPerClock;
	        if (count >= subProcess.getInstructions()) {
	            finishExecution(); 
	        }
    	}else {
			this.finishExecution();

    	}
    }

    public void finishExecution() {
        synchronized (this) {
            subProcess = null;
            count = 0;
            stop();
        }
    }

    public synchronized void setSubProcess(SubProcess subProcess) {
            this.subProcess = subProcess;
            this.count = 0; // Reseta o contador de instruções
    }
    
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public synchronized SubProcess getSubProcess() {
        return subProcess;
    }


	  public boolean isEmpty() {
	        return subProcess == null;
	    }

	    public void stop() {
	        this.running = false;
	    }
	
}


/*
@Override
public void run() {
	this.count += numOInstructionsPerClock;
	if(subProcess!=null) {
	if(this.count<=this.subProcess.getInstructions()) {
		this.finishExecution();
	}}
	else {
		this.finishExecution();

	}
}
*/
