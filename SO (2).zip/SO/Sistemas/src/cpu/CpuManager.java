package cpu;

import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import entities.ProcessSO;
import entities.SubProcess;
import exception.NoSpaceException;
import main.Execute.Values;

public class CpuManager {
    private Timer timer;

	private Core[] cores;
	public static int NUM_OF_INSTRUCTIONS_PER_CLOCK=Values.NUM_OF_INSTRUCTIONS_PER_CLOCK;
	public static int INSTRUCTIONS_PER_SECOND=Values.INSTRUCTIONS_PER_SECOND;
	public static int CLOCK_TIME=Values.CLOCK_TIME;
	public static int NUM_OF_CORES= Values.NUM_OF_CORES;
	
	public CpuManager() {
        this.timer = new Timer();

		this.cores= new Core[NUM_OF_CORES];
		for(int i=0;i<this.cores.length;i++) {
			this.cores[i]= new Core(i,NUM_OF_INSTRUCTIONS_PER_CLOCK);
		}
	}
	public void registerProcess(Integer coreId, SubProcess p) throws NoSpaceException {
        if (coreId != null) {
            this.cores[coreId].setSubProcess(p);
        } else {
            throw new NoSpaceException("No available cores");
        }
        this.clock();
    }
	public void clock() {
        if (timer != null) {
            timer.cancel();
        }
        timer = new Timer(); 
        try {
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    System.out.println("---------- CLOCK STARTED ----------");
                    executeProcesses();
                }
            }, 0, CLOCK_TIME);
        } catch (IllegalStateException e) {
        }
    }
	public void stopClock() {
	    try {
	        timer.cancel();
	    } catch (IllegalStateException e) {
	    }
	}

	  private void executeProcesses() {
	        for (int i = 0; i < this.cores.length; i++) {
	            if (!this.cores[i].isEmpty()) {
	                System.out.println("Core " + i + "  executando");
	                this.cores[i].run();
	            } else {
	                System.out.println("Core " + i + " is empty");
	            }
	        }
	    }
	
	private void printProcess() {
		System.out.println("Imprimindo o status do processador ");
		for(int i =0;i<this.cores.length;i++) {
			if(this.cores[i].getSubProcess()!=null) {
				System.out.println(this.cores[i].getSubProcess().getId());
			}
		}

	}
	public Core[] getCores() {
		return cores;
	}
	public void setCores(Core[] cores) {
		this.cores = cores;
	}
	public void finishExecution(ProcessSO p) {
		for(Core core: this.cores) {
			if(p.getId().equals(core.getSubProcess().getId())) {
				core.finishExecution();
			}
		}
	}

    public void interrupt(ProcessSO p) {
        for (Core core : this.cores) {
            if (core.getSubProcess() != null && core.getSubProcess().getId().equals(p.getId())) {
                core.stop(); // interrompe o core
                core.finishExecution(); // finaliza a execução do subprocesso
                clock();

            }
        }
    }
}
    /*
	public List<SubProcess> interrupt(ProcessSO p){
		List<SubProcess> sps = new LinkedList<SubProcess>();
		for(Core core: this.cores) {
			SubProcess sp = core.getSubProcess();
			if(sp.getId().equals(p.getId())) {
				sps.add(sp);
				core.finishExecution();
			}
		}
		clock();
		return sps;
	}
	*/

