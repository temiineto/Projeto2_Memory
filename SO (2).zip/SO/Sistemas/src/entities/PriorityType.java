package entities;

public enum PriorityType {
	BAIXA(0),MEDIA(1),ALTA(2),CRITICA(3);
	private int priorityNumber;
	
	 PriorityType(int priorityNumber){
		 this.priorityNumber=priorityNumber;
	 }

	public int getPriorityNumber() {
		return priorityNumber;
	}


}
