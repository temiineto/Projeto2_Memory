package entities;


public enum SystemCallType {
	WRITE_PROCESS, DELETE_PROCESS, CREATE_PROCESS, READ_PROCESS, DELETE_ALL,EXECUTE
}
