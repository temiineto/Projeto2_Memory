package entities;

import java.util.List;
import java.util.Objects;

import Schedule.FCFS;
import Schedule.Loterry;
import Schedule.Priority;
import Schedule.SJF;
import Schedule.Scheduler;
import Schedule.ShedulerType;
import cpu.CpuManager;
import exception.NoSpaceException;
import memory.MemoryManager;
import memory.Strategy;

public class SystemOperation {
		private static MemoryManager mm ; 
	    private static Scheduler scheduler ; 

	    public static ProcessSO systemCall(SystemCallType type,ShedulerType sc,int processSize,int timeToExecute, PriorityType priority) {
	        if (type.equals(SystemCallType.CREATE_PROCESS)) {
	        	if(mm==null) {
		        	mm = new MemoryManager(4, 256); 

	        	}
	        	if(scheduler==null) {
		        	switch (sc) {
		 	            case FCFS:
			        		scheduler= new FCFS();
		 	                break;
		 	            case SJF:
			        		scheduler= new SJF();
		 	               break;
		 	            case PRIORITY:	               
			        		scheduler= new Priority();
			 	           break;
		 	           case LOTERRY:	               
			        		scheduler= new Loterry();
			 	           break;
	
		 	        }
	        	}
	        	

	        	ProcessSO p = new ProcessSO(processSize,timeToExecute,  priority);
	        	
	            return p;
	            
	        }
	        return null;
	    }

	    public static List<SubProcess> systemCall(SystemCallType type, ProcessSO p) throws NoSpaceException {
	        switch (type) {
	            case WRITE_PROCESS:
	                if(mm.write(p)) {
		            	scheduler.execute(p);
	                }
	            	break;
	            case DELETE_PROCESS:
		           scheduler.finish(p);
	               mm.delete(p);
	               break;
	            case EXECUTE:
	            	 scheduler.execute(null);
		                break;
	           
	            case READ_PROCESS:
	            	System.out.println(scheduler.getClass().toString().replace("class Schedule.", ""));
	                return mm.read(p);	                
	        }
	        return null;
	    }
	

}
