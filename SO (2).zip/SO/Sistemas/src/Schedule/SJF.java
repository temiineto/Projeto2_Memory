package Schedule;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import cpu.Core;
import entities.ProcessSO;
import entities.SubProcess;
import entities.SystemCallType;
import entities.SystemOperation;

public class SJF extends SchedulerQueue {
	
	public SJF() {
		super(new Comparator<ProcessSO>() {
			
			@Override
			public int compare(ProcessSO sp1, ProcessSO sp2) {
                return sp1.getTimeToExecute()<sp2.getTimeToExecute()?-1:1;
			}
		});
		System.out.println(" Scheduler  SJF");

	}
	/*
	@Override
	public void execute (ProcessSO p) {
		System.out.println("****** SJS ******");

		List<SubProcess> sps = SystemOperation.systemCall(SystemCallType.READ_PROCESS, p);
		for(SubProcess sp:sps) {//k +(n*v)
			this.queue.add(sp);			
		}
		while(!this.queue.isEmpty()
				) {
			for(Core core:this.getCpu().getCores()) {
				if(core.getSubProcess()==null) {
					this.getCpu().registerProcesse(core.getId(), this.queue.poll());
				}
			};
		}
        System.out.println(this.queue);


	}
	@Override
	public void finish (ProcessSO p) {
		
	}
*/

}
