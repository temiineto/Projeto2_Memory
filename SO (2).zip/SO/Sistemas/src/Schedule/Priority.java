package Schedule;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import cpu.Core;
import entities.PriorityType;
import entities.ProcessSO;
import entities.SubProcess;
import entities.SystemCallType;
import entities.SystemOperation;

public class Priority extends SchedulerQueue {

    private PriorityQueue<ProcessSO> queue;

    public Priority() {
    	 super(new Comparator<ProcessSO>() {
             @Override
             public int compare(ProcessSO p1, ProcessSO p2) {
                 // Obter os números de prioridade dos processos
                 int priorityNumber1 = p1.getPriority().getPriorityNumber();
                 int priorityNumber2 = p2.getPriority().getPriorityNumber();

                 // Comparar os números de prioridade para determinar a ordem
                 return Integer.compare(priorityNumber2, priorityNumber1);
             }
    	    });
    	    System.out.println("Scheduler Priority");

    }
    
    
/*
    @Override
    public void execute(ProcessSO p) {
        System.out.println("****** Priority ******");

        // Adiciona o processo à fila de prioridade
        System.out.println("Queue size before: " + this.queue.size());
        this.queue.add(p);
        System.out.println("Queue size after: " + this.queue.size());

        // Processa os processos na fila de prioridade
        while (!this.queue.isEmpty()) {
            ProcessSO currentProcess = this.queue.poll();
            List<SubProcess> sps = SystemOperation.systemCall(SystemCallType.READ_PROCESS, currentProcess);
            for (SubProcess sp : sps) {
                for (Core core : this.getCpu().getCores()) {
                    if (core.getSubProcess() == null) {
                        this.getCpu().registerProcesse(core.getId(), sp);
                        break;
                    }
                }
            }
           
        }
        System.out.println("Queue size after while: " + this.queue.size());


    }

    @Override
    public void finish(ProcessSO p) {
        // Método de finalização (se necessário)
    }

*/
    
}
