package main;

import java.util.Scanner;

import Schedule.ShedulerType;
import cpu.CpuManager;
import entities.PriorityType;
import entities.ProcessSO;
import entities.SystemCallType;
import entities.SystemOperation;
import exception.NoSpaceException;

public class Execute {

    public class Values {
        public static int NUM_OF_INSTRUCTIONS_PER_CLOCK = 7;
        public static int INSTRUCTIONS_PER_SECOND = 1;
        public static int CLOCK_TIME = 500;
        public static int NUM_OF_CORES = 4;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("CPU Clock: " + CpuManager.CLOCK_TIME + "ms");
        System.out.println("CPU Instructions: " + CpuManager.NUM_OF_INSTRUCTIONS_PER_CLOCK);
        System.out.println("CPU Cores: " + CpuManager.NUM_OF_CORES);

        System.out.println("Selecione o tipo de escalonamento:");
        System.out.println("0 - FCFS");
        System.out.println("1 - SJF");
        System.out.println("2 - Priority");
        System.out.println("3 - Lottery");

        int option = scanner.nextInt();
        ShedulerType allocation = null;
        switch (option) {
            case 0:
                allocation = ShedulerType.FCFS;
                System.out.println("FCFS selecionado");
                break;
            case 1:
                allocation = ShedulerType.SJF;
                System.out.println("SJF selecionado");
                break;
            case 2:
                allocation = ShedulerType.PRIORITY;
                System.out.println("Priority selecionado");
                break;
            case 3:
                allocation = ShedulerType.LOTERRY;
                System.out.println("Lottery selecionado");
                break;
            default:
                System.out.println("Opção inválida. Encerrando programa.");
                return;
        }

        System.out.println("P1 - 130");
        System.out.println("P2 - 90");
        System.out.println("Selecione o tamanho de P3:");
        System.out.println("0 - P3 com 30");
        System.out.println("1 - P3 com 34");

        int sizeP3 = 0;
        option = scanner.nextInt();
        switch (option) {
            case 0:
                sizeP3 = 30;
                System.out.println("P3 com tamanho 30 selecionado");
                break;
            case 1:
                sizeP3 = 34;
                System.out.println("P3 com tamanho 34 selecionado");
                break;
            default:
                System.out.println("Opção inválida. Encerrando programa.");
                return;
        }

        int[] tamanho = { 130, 90, sizeP3 };
        int[] clock = { 10, 5, 15 };
        PriorityType[] priority = { PriorityType.BAIXA, PriorityType.MEDIA, PriorityType.CRITICA };
        ProcessSO p1 = (ProcessSO) SystemOperation.systemCall(SystemCallType.CREATE_PROCESS, allocation,
                tamanho[0], clock[0], priority[0]);
        ProcessSO p2 = (ProcessSO) SystemOperation.systemCall(SystemCallType.CREATE_PROCESS, allocation,
                tamanho[1], clock[1], priority[1]);
        ProcessSO p3 = (ProcessSO) SystemOperation.systemCall(SystemCallType.CREATE_PROCESS, allocation,
                tamanho[2], clock[2], priority[2]);

        try {
            System.out.println("\n****P1*****");
            SystemOperation.systemCall(SystemCallType.WRITE_PROCESS, p1);
            System.out.println("\n\n****P2*****");
            SystemOperation.systemCall(SystemCallType.WRITE_PROCESS, p2);
            System.out.println("\n\n****P3*****");
            SystemOperation.systemCall(SystemCallType.WRITE_PROCESS, p3);
            SystemOperation.systemCall(SystemCallType.EXECUTE, null);
            System.out.println("\n\n***************************** PROGRAMA CONCLUIDO EM " + allocation + " e P3-" + sizeP3
                    + " *****************************");
        } catch (NoSpaceException e) {
            e.getMessage();
        }

        scanner.close();
    }
}
