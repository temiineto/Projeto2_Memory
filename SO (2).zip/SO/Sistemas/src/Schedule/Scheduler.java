package Schedule;

import cpu.CpuManager;
import entities.ProcessSO;
import exception.NoSpaceException;
public abstract class Scheduler {
	
	protected CpuManager cpu;
	
	public Scheduler() {
		this.cpu = new CpuManager();
	}
	public abstract void execute (ProcessSO p) throws NoSpaceException;		
	public abstract void finish (ProcessSO p);
	
	public CpuManager getCpu() {
		return cpu;
	}
	public void setCpu(CpuManager cpu) {
		this.cpu = cpu;
	}
	

    public void stopClock() {
    	cpu.stopClock();
    }
 
}
